package com.groupe2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.groupe2.Model.ProduitModel;
import com.groupe2.controller.ConnexionMysql;

public class ProduitDAO {
	
	private Connection con;
	private PreparedStatement ps;
	
	// constructor 
	public ProduitDAO() {
		this.con = ConnexionMysql.getConnection();
		}
 
	public ProduitDAO(Connection con) {
		this.con = con;
		}
	
	//crud
	private static String findAll = "SELECT * FROM produit";
	private static String findByName = "SELECT * FROM produit WHERE nom = ?";
	private static String findByCode = "SELECT * FROM produit WHERE idProduit = ?";
	private static String create = "INSERT INTO produit (nom, prix, caracteristique, quantite) values (?,?,?,?)";
	private static String deleteByCode = "DELETE FROM produit WHERE idProduit = ?";
	private static String updateQuaniteByCode = "UPDATE produit SET quantite = ? WHERE idProduit = ?";
	private static String updatePrixByCode = "UPDATE produit SET prix = ? WHERE idProduit = ?";
	
	//
	
	public void testConnection() {
		
		
		if(this.con == null) {
			
			System.out.println("l'OBJECT connexion est NUULLLL ou VIDEE");
		} 
		else {
			
			System.out.println("l'OBJECT connexion EST BONNE");
			
		} 
		
	}
	
	// Création d'un produit
	public void create(ProduitModel produit ){
		
		try {
			
			ps = con.prepareStatement(ProduitDAO.create);
			
			if( ps != null ) {
				
				ps.setString(1, produit.getNom());
				ps.setDouble(2, produit.getPrix());
				ps.setString(3, produit.getCaracteristique());
				ps.setInt(4, produit.getQuantite());
				
				int rowCount = ps.executeUpdate();
				
			} else {
				System.out.println("Connexion Echoué!!!!");
			}
			
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	//
	
	// recherche de tous les produits
	public List < ProduitModel > findAll(){
		
		try {
			
			ps = con.prepareStatement(ProduitDAO.findAll);
			ResultSet rs= ps.executeQuery();
			
			List <ProduitModel> ListeProduit = new ArrayList<ProduitModel>();
			ProduitModel produit = null;
			
			while (rs.next()){
				produit = new ProduitModel();
				produit.setCodeProduit( rs.getInt("idProduit") );
				produit.setNom(rs.getString("nom"));
				produit.setPrix(rs.getFloat("prix"));
				produit.setCaracteristique(rs.getString("caracteristique"));
				produit.setQuantite(rs.getInt("quantite"));
	
				ListeProduit.add(produit);
			}
			
			return ListeProduit;
			
		} catch (SQLException e) {
			System.out.println("Erreur" + e.getMessage());
			return null;
		}
	}
	
	// recherche d'un produit par son nom
	public ProduitModel findOneByName(String name){
		
		try {
			
			ps = con.prepareStatement(ProduitDAO.findByName);
			ps.setString(1, name);
			ResultSet rs = ps.executeQuery();
			ProduitModel produit = null;
			
			while (rs.next()){
				produit = new ProduitModel();
				produit.setCodeProduit( rs.getInt("idProduit") );
				produit.setNom(rs.getString("nom"));
				produit.setPrix(rs.getFloat("prix"));
				produit.setCaracteristique(rs.getString("caracteristique"));
				produit.setQuantite(rs.getInt("quantite"));
			}
			
			return produit;
			
		} catch (SQLException e) {
			System.out.println("erreur" + e.getMessage());
			return null;
		}
	}
	
	// recherche d'un produit par son code
	public ProduitModel findOneByCode(int code){
		
		try {
			ps = con.prepareStatement(ProduitDAO.findByCode);
			ps.setInt(1, code);
			
			ResultSet rs = ps.executeQuery();
			ProduitModel produit = null;
			
			while(rs.next()) {
				
				produit = new ProduitModel();
				produit.setCodeProduit( rs.getInt("idProduit") );
				produit.setNom(rs.getString("nom"));
				produit.setPrix(rs.getFloat("prix"));
				produit.setCaracteristique(rs.getString("caracteristique"));
				produit.setQuantite(rs.getInt("quantite"));
				
			}
			
			return produit;
			
		} catch (SQLException e) {
			System.out.println("erreur" + e.getMessage());
			return null;
		}
	}
	

	// suppression d'un produit par son code
	public void deleteByCode(int code){
			
			try {
				ps = con.prepareStatement(ProduitDAO.deleteByCode);
				ps.setInt(1, code);
				
				int rowDelete = ps.executeUpdate();
				
				if( rowDelete != 0 ) System.out.println(" Suppression de " + code + " avec SUCCES!!");
				else System.out.println(" Suppression de " + code + " avec ECHEC!!");
				
			} catch (SQLException e) {
				System.out.println("erreur" + e.getMessage());
			}

		}
	
	// modification de la quantité d'un produit par son code
	public void updateQuaniteByCode(int idProduit, int newQuantite){
			
			try {
				ps = con.prepareStatement(ProduitDAO.updateQuaniteByCode);
				ps.setInt(1, newQuantite);
				ps.setInt(2, idProduit);
				
				int rowUpdate = ps.executeUpdate();
				
				if( rowUpdate != 0 ) System.out.println(" modification de " + newQuantite + " avec SUCCES!!");
				else System.out.println(" Suppression de " + newQuantite + " avec ECHEC!!");
				
			} catch (SQLException e) {
				System.out.println("erreur" + e.getMessage());
			}

		}
	
	// modification de la quantité d'un produit par son code
	public void updatePrixByCode(int idProduit, double newPrix){
			
			try {
				ps = con.prepareStatement(ProduitDAO.updatePrixByCode);
				ps.setDouble(1, newPrix);
				ps.setInt(2, idProduit);
				
				int rowUpdate = ps.executeUpdate();
				
				if( rowUpdate != 0 ) System.out.println(" modification de " + newPrix + " avec SUCCES!!");
				else System.out.println(" Suppression de " + newPrix + " avec ECHEC!!");
				
			} catch (SQLException e) {
				System.out.println("erreur" + e.getMessage());
			}

		}



}
