package com.groupe2.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.groupe2.Model.UsersModel;
import com.groupe2.controller.ConnexionMysql;

public class UsersDAO {
	
	

	private static Connection con;
	private static PreparedStatement ps;
	
	// constructor 
	public UsersDAO() {
		this.con = ConnexionMysql.getConnection();
		}
 
	public UsersDAO(Connection con) {
		this.con = con;
		}
	
	//crud
	
	private static String findAll = "SELECT * FROM login";
	private static String findOneByName = "SELECT * FROM login WHERE Username = ?";
	private static String findOneByLoginAndPassword = "SELECT * FROM login WHERE Username = ? and Password= ?";
	private static String findByCode = "SELECT * FROM login WHERE Id_login = ?";
	private static String create = "INSERT INTO login (Username, Password, Type) values (?,?,?)";
	private static String deleteByCode = "DELETE FROM login WHERE Id_login = ?";
	private static String updateUsernameByCode = "UPDATE login SET Username = ? WHERE Id_login = ?";
	private static String updatePasswordByCode = "UPDATE produit SET Password = ? WHERE Id_login = ?";
	private static String updateTypeByCode = "UPDATE produit SET Type = ? WHERE Id_login = ?";
	
	//
	
	public void testConnection() {
		
		
		if(this.con == null) {
			
			System.out.println("l'OBJECT connexion est NUULLLL ou VIDEE");
		} 
		else {
			
			System.out.println("l'OBJECT connexion EST BONNE");
			
		} 
		
	}
	
	// Création d'un produit
	public void create(UsersModel produit ){
		
		try {
			
			ps = con.prepareStatement(UsersDAO.create);
			
			if( ps != null ) {
				
				ps.setString(1, produit.getUsername());
				ps.setString(2, produit.getPassword());
				ps.setString(3, produit.getType());
				
				
				int rowCount = ps.executeUpdate();
				
			} else {
				System.out.println("Connexion Echoué!!!!");
			}
			
		} catch (SQLException ex) {
			System.out.println(ex.getMessage());
		}
	}
	
	//
	
	// recherche de tous les utilisateurs
	public List<UsersModel> findAll(){
		
		try {
			
			ps = con.prepareStatement(UsersDAO.findAll);
			ResultSet rs= ps.executeQuery();
			
			List <UsersModel> ListeUsers = new ArrayList<UsersModel>();
			UsersModel user = null;
			
			while (rs.next()){
				user = new UsersModel();
				user.setId_login( rs.getInt("Id_Login") );
				user.setUsername(rs.getString("Username"));
				user.setPassword(rs.getString("Password"));
				user.setType(rs.getString("Type"));
	
				ListeUsers.add(user);
			}
			
			return ListeUsers;
			
		} catch (SQLException e) {
			System.out.println("Erreur" + e.getMessage());
			return null;
		}
	}
	
	// recherche d'un utilisateur par son nom
	public UsersModel findOneByName(String username){
		
		try {
			
			ps = con.prepareStatement(UsersDAO.findOneByName);
			ps.setString(1, username);
			ResultSet rs = ps.executeQuery();
			UsersModel user = null;
			
			while (rs.next()){
				user = new UsersModel();
				user.setId_login( rs.getInt("Id_Login") );
				user.setUsername(rs.getString("Username"));
				user.setPassword(rs.getString("Password"));
				user.setType(rs.getString("Type"));
				
			}
			
			return user;
			
		} catch (SQLException e) {
			System.out.println("erreur" + e.getMessage());
			return null;
		}
	}
	
	// recherche d'un utilisateur par son code
	public UsersModel findOneByCode(int code){
		
		try {
			ps = con.prepareStatement(UsersDAO.findByCode);
			ps.setInt(1, code);
			
			ResultSet rs = ps.executeQuery();
			UsersModel user = null;
			
			while(rs.next()) {
				
				user = new UsersModel();
				user.setId_login( rs.getInt("Id_login") );
				user.setUsername(rs.getString("Username"));
				user.setPassword(rs.getString("Password"));
				user.setType(rs.getString("Type"));
				
			}
			
			return user;
			
		} catch (SQLException e) {
			System.out.println("erreur" + e.getMessage());
			return null;
		}
	}
	

	// suppression d'un utilisateur par son code
	public void deleteByCode(int code){
			
			try {
				ps = con.prepareStatement(UsersDAO.deleteByCode);
				ps.setInt(1, code);
				
				int rowDelete = ps.executeUpdate();
				
				if( rowDelete != 0 ) System.out.println(" Suppression de " + code + " avec SUCCES!!");
				else System.out.println(" Suppression de " + code + " avec ECHEC!!");
				
			} catch (SQLException e) {
				System.out.println("erreur" + e.getMessage());
			}

		}
	
	// modification du nom d'utilisateur par l'id
	public void updateUsernameByCode (int Id_login, int newUsername){
			
			try {
				ps = con.prepareStatement(UsersDAO.updateUsernameByCode);
				ps.setInt(1, newUsername);
				ps.setInt(2, Id_login);
				
				int rowUpdate = ps.executeUpdate();
				
				if( rowUpdate != 0 ) System.out.println(" modification de " + newUsername + " avec SUCCES!!");
				else System.out.println(" Suppression de " + newUsername + " avec ECHEC!!");
				
			} catch (SQLException e) {
				System.out.println("erreur" + e.getMessage());
			}

		}
	
	// modification du mot de passe d'un utilisateur par son id
	public void updatePasswordByCode(int Id_login, String newPassword){
			
			try {
				ps = con.prepareStatement(UsersDAO.updatePasswordByCode);
				ps.setString(1, newPassword);
				ps.setInt(2, Id_login);
				
				int rowUpdate = ps.executeUpdate();
				
				if( rowUpdate != 0 ) System.out.println(" modification de " + newPassword + " avec SUCCES!!");
				else System.out.println(" Suppression de " + newPassword + " avec ECHEC!!");
				
			} catch (SQLException e) {
				System.out.println("erreur" + e.getMessage());
			}

		}
	
	public void updateTypeByCode(int Id_login, String newType){
		
		try {
			ps = con.prepareStatement(UsersDAO.updateTypeByCode);
			ps.setString(1, newType);
			ps.setInt(2, Id_login);
			
			int rowUpdate = ps.executeUpdate();
			
			if( rowUpdate != 0 ) System.out.println(" modification de " + newType + " avec SUCCES!!");
			else System.out.println(" Suppression de " + newType + " avec ECHEC!!");
			
		} catch (SQLException e) {
			System.out.println("erreur" + e.getMessage());
		}

	}

	
public static UsersModel findOneByLoginAndPassword(String username, String password){
		
		try {
			
			ps = con.prepareStatement(UsersDAO.findOneByLoginAndPassword);
			ps.setString(1, username);
			ps.setString(2, password);
			ResultSet rs = ps.executeQuery();
			UsersModel user = null;
			
			while (rs.next()){
				user = new UsersModel();
				user.setId_login( rs.getInt("Id_Login") );
				user.setUsername(rs.getString("Username"));
				user.setPassword(rs.getString("Password"));
				user.setType(rs.getString("Type"));
				
			}
			
			return user;
			
		} catch (SQLException e) {
			System.out.println("erreur" + e.getMessage());
			return null;
		}
	}
	
	
	

}
