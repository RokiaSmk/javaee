package com.groupe2.controller;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;



import com.groupe2.Model.UsersModel;
import com.groupe2.dao.UsersDAO;

/**
 * Servlet implementation class LoginServlet
 */
//@WebServlet("LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UsersDAO userDao;

       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
        this.userDao= new UsersDAO();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
//		this.getServletContext().getRequestDispatcher("LoginDisplay.jsp").forward(request, response);
	} 



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		//doGet(request, response);
		String username=request.getParameter("uname");
		String password=request.getParameter("psw");
		String type=request.getParameter("type");
		UsersModel existeUser = userDao.findOneByLoginAndPassword(username, password);
		if(existeUser != null) {
		
			System.out.println("type est:" + type);
			
			switch (type) {
	        case "user":
	        	request.getRequestDispatcher("UserDisplay.jsp").forward(request, response);
	            break;
	        case "admin":
	        	request.getRequestDispatcher("AdminDisplay.jsp").forward(request, response);
	            break;
	      
	        case "manager":
	        	request.getRequestDispatcher("ManagerDisplay.jsp").forward(request, response);
	            break;
	            
	        default: 
	        	request.getRequestDispatcher("LoginDisplay.jsp").forward(request, response);
	            break;
	    }
			
		}else {
			request.getRequestDispatcher("LoginDisplay.jsp").forward(request, response);
		}
		
		
		
		
		
		
		
	}
	}

