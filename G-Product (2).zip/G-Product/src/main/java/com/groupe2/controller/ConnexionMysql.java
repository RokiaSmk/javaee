package com.groupe2.controller;

import java.sql.Connection;
import java.sql.DriverManager;

public class ConnexionMysql {
	
private static Connection con;
	
public static Connection getConnection(){
	
	if(con == null){
		
		try{
		    //étape 1: charger la classe de driver
		      Class.forName("com.mysql.cj.jdbc.Driver");
		      //Class.forName("com.mysql.jdbc.Driver");
		      //étape 2: créer l'objet de connexion
		      con = DriverManager.getConnection("jdbc:mysql://localhost:3306/g_product","root", "");
		      
		      System.out.println("Connection reussite avec SUCCES !!! ");
		      
			}catch(Exception e){ 
				e.printStackTrace();
				System.out.println("Connection non reussite!!! :  " + e.getMessage());
			    
			}
		
	}
	
	return con;
	
}

}
