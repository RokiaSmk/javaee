package com.groupe2.Model;

public class UsersModel {
	private static int Id_login;
	private static String Username;
	private static String Password;
	private static String Type;
	
	public UsersModel() {
		super();

	}
	
	public UsersModel( String username, String password, String type) {
		super();
		Username = username;
		Password = password;
		Type = type;
	}
	
	public UsersModel( String username, String password) {
		super();
		Username = username;
		Password = password;

	}
	
	public UsersModel(int id_login, String username, String password, String type) {
		super();
		Id_login = id_login;
		Username = username;
		Password = password;
		Type = type;
	}
	
	public static int getId_login() {
		return Id_login;
	}
	public void setId_login(int id_login) {
		Id_login = id_login;
	}
	public static String getUsername() {
		return Username;
	}

	public void setUsername(String username) {
		Username = username;
	}
	public static String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public static String getType() {
		return Type;
	}
	public void setType(String type) {
		Type = type;
	}

	@Override
	public String toString() {
		return "UsersModel [Id_login=" + Id_login + ", Username=" + Username + ", Password=" + Password + ", Type="
				+ Type + "]";
	}

	
	
}
