package com.groupe2.Model;

public class ProduitModel {
	private int codeProduit;
	private String nom;
	private double prix;
	private String caracteristique;
	private int quantite;
	

	public ProduitModel() {
		super();
	}


	public ProduitModel(int codeProduit, String nom, double prix, String caracteristique, int quantite) {
		super();
		codeProduit = codeProduit;
		this.nom = nom;
		this.prix = prix;
		this.caracteristique = caracteristique;
		this.quantite = quantite;
	}
	
	public ProduitModel( String nom, double prix, String caracteristique, int quantite) {
		super();
		this.nom = nom;
		this.prix = prix;
		this.caracteristique = caracteristique;
		this.quantite = quantite;
	}


	public int getCodeProduit() {
		return codeProduit;
	}


	public void setCodeProduit(int id_Produit) {
		codeProduit = id_Produit;
	}


	public String getNom() {
		return nom;
	}


	public void setNom(String nom) {
		this.nom = nom;
	}


	public double getPrix() {
		return prix;
	}


	public void setPrix(double prix) {
		this.prix = prix;
	}


	public String getCaracteristique() {
		return caracteristique;
	}


	public void setCaracteristique(String caracteristique) {
		this.caracteristique = caracteristique;
	}


	public int getQuantite() {
		return quantite;
	}


	public void setQuantite(int quantite) {
		this.quantite = quantite;
	}


	@Override
	public String toString() {
		return "ProduitModel [codeProduit=" + codeProduit + ", nom=" + nom + ", prix=" + prix + ", caracteristique="
				+ caracteristique + ", quantite=" + quantite + "]";
	}
	
	

}
